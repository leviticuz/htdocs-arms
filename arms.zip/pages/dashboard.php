<h2>Dashboard</h2>
<p>Welcome to your dashboard! Here you can see an overview of your system.</p>

<!-- Example Stats Section -->
<div class="row">
    <div class="col-md-4">
        <div class="card bg-primary text-white p-3">
            <h4>Total Users</h4>
            <p>150</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white p-3">
            <h4>Active Sessions</h4>
            <p>25</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-white p-3">
            <h4>Pending Requests</h4>
            <p>8</p>
        </div>
    </div>
</div>

<!-- Example Recent Activity -->
<h3 class="mt-4">Recent Activity</h3>
<ul class="list-group">
    <li class="list-group-item">User John logged in.</li>
    <li class="list-group-item">Admin updated settings.</li>
    <li class="list-group-item">New user registration: Jane Doe.</li>
</ul>
