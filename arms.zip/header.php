<?php
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'ARMS System' ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
        integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <style>
        .bg-navy {
            background: linear-gradient(90deg, #002B5C,rgb(162, 0, 255));
        }
        .bg-linear{
            background-color: #002B5C;
        }
    </style>
</head>

<body class="bg-light">
    <!-- Sticky Header -->
    <header class="fixed-top bg-navy text-white py-3 shadow-sm">
        <div class="container-fluid d-flex justify-content-between align-items-center px-4">
            <div class="fs-4 fw-bold">NAVMETOC ARMS System</div>
            <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle bg-secondary" style="width: 40px; height: 40px;"></div>
                <div>
                    <div class="fw-bold">John Doe</div>
                    <div class="text-light small">User</div>
                </div>
                <i class="fa-solid fa-caret-down"></i>
            </div>
        </div>
    </header>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
