<?php
$pageTitle = 'ARMS Login';
include("header.php");
?>

<main class="d-flex flex-column justify-content-center align-items-center vh-100 bg-light">
    
    <!-- Login Card -->
    <div class="card shadow-lg p-4 mt-5" style="width: 350px;">
        <h2 class="text-center">Login</h2>

        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

        <form action="api/confirm.php" method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" class="form-control" name="username" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" class="form-control" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
    </div>

    <!-- Bootstrap JS (optional, for components like modals) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</main>
</body>
</html>
