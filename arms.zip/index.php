<?php
    // include("config/session.php");
    include("header.php");
?>

<main class="d-flex">
    <!-- Sidebar -->
    <nav class="bg-linear text-dark mt-4 p-2 shadow-sm" style="width: 250px; height: 100vh; position: fixed; top: 53px;">
        <h4 class="text-center text-white pt-2 pb-2">Menu</h4>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link text-white" href="#" onclick="loadPage('dashboard')">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#" onclick="loadPage('assets')">Assets Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#" onclick="loadPage('duty_profile')">Duty Profile History</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#" onclick="loadPage('personnel_dues')">Personnel Dues</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#" onclick="loadPage('personnel_tracking')">Personnel Tracking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#" onclick="loadPage('roster')">Roster of Troops</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div id = "main-content" class="flex-grow-1 p-4" style="margin-left: 250px; margin-top: 70px;">
        <?php include('pages/dashboard.php'); ?>
    </div>
</main>
<script>
    function loadPage(page) {
        fetch(`pages/${page}.php`)
        .then(response => response.text())
        .then(data => {
            document.getElementById('main-content').innerHTML = data;
        })
        .catch(error => console.error('Error loading page:', error));
    }
</script>

</body>
</html>
